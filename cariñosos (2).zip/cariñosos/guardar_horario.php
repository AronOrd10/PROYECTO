<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recopila los datos del formulario
    $hora_entrada = $_POST['hora_entrada'];
    $hora_salida = $_POST['hora_salida'];
    $cantidad_horas = $_POST['cantidad_horas'];
    $id_empleado = $_POST['id_empleado'];

    // Realiza la inserción en la base de datos
    $sql = "INSERT INTO tb_horario (hora_entrada, hora_salida, cantidad_horas, id_empleado) 
            VALUES ('$hora_entrada', '$hora_salida', $cantidad_horas, '$id_empleado')";

    if (mysqli_query($mysqli, $sql)) {
        echo '<script language="javascript">';
        echo 'alert("Guardado exitosamente");';
        echo 'window.location="horarios.php";';  // Cambia "horarios.php" por la página a la que deseas redirigir
        echo '</script>';
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
    }
}
?>
