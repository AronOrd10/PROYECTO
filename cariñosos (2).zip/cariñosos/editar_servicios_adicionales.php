<?php
include("config.php");

// Verificar si se recibió el parámetro 'id' en la URL
if(isset($_GET['id'])) {
    // Obtener el valor del parámetro 'id'
    $id = $_GET['id'];

    // Preparar la consulta SQL para obtener los datos del paciente
    $result = mysqli_query($mysqli, "SELECT * FROM tb_servicios_adicionales WHERE id_persona = $id");

    // Verificar si se encontró el paciente
    if(mysqli_num_rows($result) > 0) {
        // Mostrar los datos del paciente en un formulario para su actualización
        while ($row = mysqli_fetch_array($result)) {
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Actualizar Servicio Adicionales</title>
</head>
<body>
    <!-- Creamos un menú -->
    <div class="icon-bar">
        <a href="home.html"><i class="fa fa-home"></i></a>
        <a href="personas.php"><i class="fa fa-user"></i></a>
    </div>

    <h2>Actualizar Servicio Adicionales</h2>
    <hr />

    <form action="guardar_servicios_adicionales.php" method="POST">
        <div class="container">
            <input type="hidden" name="id" value="<?php echo $row['nombre_servicio']; ?>" required>
            <label for="nombre_servicio"><b>Nombre Del Servicio:</b></label>
            <input type="text" name="nombre_servicio" value="<?php echo $row['nombre_servicio']; ?>" required>

            <label for="descripcion"><b>Descripcion:</b></label>
            <input type="text" name="descripcion" value="<?php echo $row['descripcion']; ?>" required>

            <label for="costi"><b>Costo:</b></label>
            <input type="text" name="costo" value="<?php echo $row['costo']; ?>" required>

            <label for="estado"><b>Estado:</b></label>
            <input type="date" name="estado" value="<?php echo $row['estado']; ?>" required>

            <label for="id_cliente"><b>ID Cliente:</b></label>
            <input type="text" name="id_cliente" value="<?php echo $row['id_cliente']; ?>" required>

            <label for="id_reserva_servicio_adicionales"><b>ID Reserva Servicio Adicionales:</b></label>
            <input type="text" name="id_servicio_adicionales" value="<?php echo $row['id_servicio_adicionales']; ?>" required>

            <div class="clearfix">
                <button type="submit" class="signupbtn">Actualizar</button>
            </div>
        </div>
    </form>
</body>
</html>
<?php
        }
    } else {
        echo "No se encontraron datos para el servicio adicionales con ID $id";
    }
} else {
    echo "No se recibió el ID de servicion adicionales";
}
?>
