<?php
include("config.php");

$query = "SELECT * FROM tb_medico";
$result = mysqli_query($mysqli, $query);

// Manejo de errores
if (!$result) {
    die('Error en la consulta: ' . mysqli_error($mysqli));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>medico</title>
</head>

<body>
    <!-- Creamos un menú -->
    <div class="icon-bar">
        <a href="registro.php"><i class="fa fa-registered"></i></a>
        <a href="home.html"><i class="fa fa-home"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>Médicos</h2>
    <hr>

    <div class="container">
        <!-- Creo la tabla para presentar los médicos -->
        <?php
        echo "<table>";
        echo "<tr><th>ID</th><th>Especialidad</th><th>ID Persona</th><th>Correo</th><th>Actualizar</th><th>Eliminar</th></tr>";
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['id_medico'] . "</td>";
            echo "<td>" . $row['especialidad'] . "</td>";
            echo "<td>" . $row['id_persona'] . "</td>";
            echo "<td>" . $row['correo'] . "</td>";
            echo "<td><a href='editar_medico.php?id=" . $row['id_medico'] . "'><img src='./images/icons8-Edit-32.png' alt='Edit'></a></td>";
            echo "<td><a href='eliminar_medico.php?id=" . $row['id_medico'] . "'><img src='./images/icons8-Trash-32.png' alt='Delete'></a></td>";
            echo "</tr>";
        }
        echo "</table>";
        ?>
    </div>
</body>

</html>
