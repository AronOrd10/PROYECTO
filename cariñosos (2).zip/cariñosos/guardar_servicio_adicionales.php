<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recopila los datos del formulario
    $nombre_servicio = $_POST['nombre_servicio'];
    $descripcion = $_POST['descripcion'];
    $costo = $_POST['costo'];
    $estado = $_POST['estado'];
    $id_cliente = $_POST['id_cliente'];

    // Realiza la inserción en la base de datos
    $sql = "INSERT INTO tb_servicio_adicionales (nombre_servicio, escripcion, costo, estado, id_cliente, id_cliente) 
            VALUES ('$nombre_servicio', '$escripcion', '$costo', '$estado', '$id_cliente', '$id_cliente')";

    if (mysqli_query($mysqli, $sql)) {
        echo '<script language="javascript">';
        echo 'alert("Guardado exitosamente");';
        echo 'window.location="citas.php";';  // Cambia "tu_pagina.php" por la página a la que deseas redirigir
        echo '</script>';
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
    }
}
?>
