<?php
//Conexion
include("config.php");
$id = $_POST['id'];
$apellido =$_POST['apellido']
$nombre =$_POST['nombre']
$cedula =$_POST['cedula']
$fecha_nacimiento =$_POST['fecha_nacimiento']
$direccion=$_POST['apellido']
$edad =$_POST['edad']
$sexo =$_POST['sexo']
$id_telefono =$_POST['id_telefono']
$id_usauario =$_POST['id_usuario']
$discapacidad =$_POST['discapacidad']
$estado =$_POST['estado']
$sql = "UPDATE tb_persona SET apellido, nombre, cedula, fecha_nacimiento, direccion, edad, sexo, id_telefono, id_usuario, discapacidad, estado = '$apellido', '$nombre',  '$cedula', '$fecha_nacimiento', '$direccion', '$edad', '$sexo', '$id_telefono', '$id_usuario', '$discapacidad', '$estado'
WHERE id_persona = $id";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'window.location="personas.php";';
	echo '</script>';	
}
?>