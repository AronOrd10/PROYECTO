<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recopila los datos del formulario

   
        // Insertar datos de cliente en la tabla correspondiente
        $sql_cliente = "INSERT INTO tb_cliente (id_cliente, id_persona, codigo_cliente) 
                        VALUES ('$id_cliente', '$id_persona', '$codigo_cliente')";

        if (mysqli_query($mysqli, $sql_cliente)) {
            echo '<script language="javascript">';
            echo 'alert("Guardado exitosamente");';
            echo 'window.location="personas.php";';  // Cambia "cliente.php" por la página a la que deseas redirigir
            echo '</script>';
        } else {
            echo "Error: " . $sql_cliente . "<br>" . mysqli_error($mysqli);
        }
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
    }

?>
