<?php 
include("config.php");

$id = $_GET['id'];

$sql ="UPDATE tb_horario SET estado = 0 WHERE id_horario = $id";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
    echo 'window.location="personas.php";';
    echo '</script>';
}
?> 
