<?php
include("config.php");

// Verificar si se recibió el parámetro 'id' en la URL
if(isset($_GET['id'])) {
    // Obtener el valor del parámetro 'id'
    $id = $_GET['id'];

    // Preparar la consulta SQL para obtener los datos de la cita
    $result = mysqli_query($mysqli, "SELECT * FROM tb_cita WHERE id_cita = $id");

    // Verificar si se encontró la cita
    if(mysqli_num_rows($result) > 0) {
        // Mostrar los datos de la cita en un formulario para su actualización
        while ($row = mysqli_fetch_array($result)) {
            ?>
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" type="text/css" href="css/mystyle1.css">
                <title>Actualizar Cita</title>
            </head>
            <body>
                <h2>Actualizar Cita</h2>
                <hr />

                <form action="guardar_cita.php" method="POST">
                    <div class="container">
                        <input type="hidden" name="id" value="<?php echo $row['id_cita']; ?>" required>
                        <label for="fecha"><b>Fecha:</b></label>
                        <input type="date" name="fecha" value="<?php echo $row['fecha']; ?>" required>

                        <label for="hora"><b>Hora:</b></label>
                        <input type="time" name="hora" value="<?php echo $row['hora']; ?>" required>

                        <label for="id_paciente"><b>ID Paciente:</b></label>
                        <input type="text" name="id_paciente" value="<?php echo $row['id_paciente']; ?>" required>

                        <div class="clearfix">
                            <button type="submit" class="signupbtn">Actualizar</button>
                        </div>
                    </div>
                </form>
            </body>
            </html>
            <?php
        }
    } else {
        echo "No se encontraron datos para la cita con ID $id";
    }
} else {
    echo "No se recibió el ID de la cita";
}
?>
