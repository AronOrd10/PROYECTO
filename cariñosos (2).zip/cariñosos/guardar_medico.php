<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recopila los datos del formulario
    $especialidad = $_POST['especialidad'];
    $id_persona = $_POST['id_persona'];
    $correo = $_POST['correo'];

    // Realiza la inserción en la base de datos
    $sql = "INSERT INTO tb_medico (especialidad, id_persona, correo) 
            VALUES ('$especialidad', '$id_persona', '$correo')";

    if (mysqli_query($mysqli, $sql)) {
        echo '<script language="javascript">';
        echo 'alert("Guardado exitosamente");';
        echo 'window.location="medico.php";';  // Cambia "medico.php" por la página a la que deseas redirigir
        echo '</script>';
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
    }
}
?>
