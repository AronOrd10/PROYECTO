<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>Ingresar Datos de Citas</title>
</head>
<body>
    <!-- Creamos un menú -->
    <div class="icon-bar">
        <a href="inicio.php"><i class="fa fa-home"></i></a>
        <a href="citas.php"><i class="fa fa-calendar"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>Ingresar Datos de Citas</h2>
    <hr>
    <!-- Formulario para ingresar los datos de la cita -->
    <form action="guardar_cita.php" method="POST">
        <div class="container">
            <label for="fecha"><b>Fecha:</b></label>
            <input type="date" name="fecha" required>

            <label for="hora"><b>Hora:</b></label>
            <input type="time" name="hora" required>

            <label for="id_paciente"><b>ID Paciente:</b></label>
            <input type="text" name="id_paciente" required>

            <div class="clearfix">
                <button type="submit" class="signupbtn">Guardar</button>
            </div>
        </div>
    </form>
</body>
</html>
