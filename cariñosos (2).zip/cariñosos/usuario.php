
<?php
// Inicia la sesión para poder acceder a las variables de sesión
session_start();

// Verifica si el usuario ha iniciado sesión
if(isset($_SESSION['username'])) {
    // Si el usuario ha iniciado sesión, muestra el nombre de usuario
    $usuario = $_SESSION['username'];
    echo "Bienvenido, $usuario!";
} else {
    // Si el usuario no ha iniciado sesión, redirige al formulario de inicio de sesión
    header("Location: home.html");
    exit();
}
?>

