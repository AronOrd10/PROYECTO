<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recopila los datos del formulario
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $cedula = $_POST['cedula'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $direccion = $_POST['direccion'];
    $edad = $_POST['edad'];
    $sexo = $_POST['sexo'];
    $id_telefono = $_POST['id_telefono'];
    $id_usuario = $_POST['id_usuario'];
    $discapacidad = $_POST['discapacidad'];
    $estado = $_POST['estado'];

    // Realiza la inserción en la base de datos
    $sql = "INSERT INTO tb_persona (nombre,apellido, cedula, fecha_nacimiento, direccion, edad, sexo, id_telefono, id_usuario, discapacidad, estado) 
            VALUES ('$nombre','$apellido', '$cedula', '$fecha_nacimiento', '$direccion', $edad, '$sexo', '$id_telefono', '$id_usuario', '$discapacidad', $estado)";

    if (mysqli_query($mysqli, $sql)) {
        echo '<script language="javascript">';
        echo 'alert("Guardado exitosamente");';
        echo 'window.location="personas.php";';  // Cambia "tu_pagina.php" por la página a la que deseas redirigir
        echo '</script>';
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
    }
}
?>