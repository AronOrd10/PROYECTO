<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    // Obtener el ID del cliente de la URL
    $id = $_GET['id'];

    // Actualizar el estado del cliente a inactivo (estado = 0)
    $sql ="UPDATE tb_forma_pago SET estado = 0 WHERE id_forma_pago= $id";

    if(mysqli_query($mysqli, $sql)) {
        // Redireccionar a la página de clientes después de la actualización
        echo '<script language="javascript">';
        echo 'window.location="clientes.php";';
        echo '</script>';
    } else {
        echo "Error al actualizar el estado de la forma pago " . mysqli_error($mysqli);
    }
} else {
    echo "No se recibió el ID de la forma pago";
}
?>
