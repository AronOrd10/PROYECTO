<?php
include("config.php");

// Verificar si se recibió el parámetro 'id' en la URL
if(isset($_GET['id'])) {
    // Obtener el valor del parámetro 'id'
    $id = $_GET['id'];

    // Preparar la consulta SQL para actualizar el estado de la cita
    $sql ="UPDATE tb_cita SET estado = 0
            WHERE id_cita = $id";

    // Ejecutar la consulta SQL
    if(mysqli_query($mysqli, $sql)){
        echo '<script language="javascript">';
        echo 'window.location="citas.php";';  // Redirigir a la página de citas después de actualizar
        echo '</script>';
    } else {
        echo "Error al actualizar el estado de la cita: " . mysqli_error($mysqli);
    }
} else {
    echo "No se recibió el ID de la cita";
}
?>
