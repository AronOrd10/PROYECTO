<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>Ingresar Datos</title>
</head>
<body>
    <!-- Creamos un menú -->
    <div class="icon-bar">
        <a href="inicio.php"><i class="fa fa-home"></i></a>
        <a href="persona.php"><i class="fa fa-user"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>Personas</h2>
    <hr>
        <!-- Creo un formulario para ingresar los datos -->
        <form action="guardar.php" method="POST">
        <div class="container">
            <label for="nombre"><b>Nombre:</b></label>
            <input type="text" name="nombre" required>

            <label for="apellido"><b>Apellido:</b></label>
            <input type="text" name="apellido" required>

            <label for="cedula"><b>Cédula:</b></label>
            <input type="text" name="cedula" required>

            <label for="fecha_nacimiento"><b>Fecha de Nacimiento:</b></label>
            <input type="date" name="fecha_nacimiento" required>

            <label for="direccion"><b>Dirección:</b></label>
            <input type="text" name="direccion" required>

            <label for="edad"><b>Edad:</b></label>
            <input type="number" name="edad" required>

            <label for="sexo"><b>Sexo:</b></label>
            <select name="sexo" required>
                <option value="M">Masculino</option>
                <option value="F">Femenino</option>
            </select>

            <label for="id_telefono"><b>ID Teléfono:</b></label>
            <input type="text" name="id_telefono" required>

            <label for="id_usuario"><b>ID Usuario:</b></label>
            <input type="text" name="id_usuario" required>

            <label for="discapacidad"><b>Discapacidad:</b></label>
            <input type="text" name="discapacidad" required>

            <label for="estado"><b>Estado:</b></label>
            <input type="text" name="estado" required>

            <div class="clearfix">
                <button type="submit" class="signupbtn">Guardar</button>
            </div>
        </div>
    </form>

</body>
</html>