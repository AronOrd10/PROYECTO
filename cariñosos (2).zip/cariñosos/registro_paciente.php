<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>Ingresar Datos</title>
</head>
<body>
    <!-- Creamos un menú -->
    <div class="icon-bar">
        <a href="inicio.php"><i class="fa fa-home"></i></a>
        <a href="persona.php"><i class="fa fa-user"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>Usuarios</h2>
    <hr>
    <!-- Creo un formulario para ingresar los datos -->
    <form action="guardar_paciente.php" method="POST">
        <div class="container">
            <label for="nombres"><b>Nombres:</b></label>
            <input type="text" name="nombres" required>

            <label for="apellidos"><b>Apellidos:</b></label>
            <input type="text" name="apellidos" required>

            <label for="fecha_nacimiento"><b>Fecha de Nacimiento:</b></label>
            <input type="date" name="fecha_nacimiento" required>

            <label for="sexo"><b>Sexo:</b></label>
            <select name="sexo" required>
                <option value="M">Masculino</option>
                <option value="F">Femenino</option>
            </select>

            <label for="id_empleado"><b>ID Empleado:</b></label>
            <input type="text" name="id_empleado" required>

            <label for="id_cliente"><b>ID Cliente:</b></label>
            <input type="text" name="id_cliente" required>

            <div class="clearfix">
                <button type="submit" class="signupbtn">Guardar</button>
            </div>
        </div>
    </form>
</body>
</html>
