<?php
session_start();

// Verificar si se han enviado los datos del formulario
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Verificar si ambos campos están vacíos
    if(empty($username) || empty($password)) {
        // Mostrar mensaje de error y redirigir de vuelta al formulario de inicio de sesión
        header("location: index.php?error=empty");
        exit();
    }

    // Verificar si las credenciales son válidas (aquí puedes usar una base de datos o cualquier otro método de autenticación)
    if($username === "usuario" && $password === "contraseña") {
        // Iniciar sesión y redirigir al usuario a una página de bienvenida
        $_SESSION['username'] = $username;
        header("location: bienvenida.php");
        exit();
    } else {
        // Si las credenciales no son válidas, redirigir de vuelta al formulario de inicio de sesión con un mensaje de error
        header("location: index.php?error=invalid");
        exit();
    }
}
?>
