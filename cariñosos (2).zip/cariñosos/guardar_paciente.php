<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recopila los datos del formulario
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $sexo = $_POST['sexo'];
    $id_empleado = $_POST['id_empleado'];
    $id_cliente = $_POST['id_cliente'];

    // Realiza la inserción en la base de datos
    $sql = "INSERT INTO tb_paciente (nombres, apellidos, fecha_nacimiento, sexo, id_empleado, id_cliente) 
            VALUES ('$nombres', '$apellidos', '$fecha_nacimiento', '$sexo', '$id_empleado', '$id_cliente')";

    if (mysqli_query($mysqli, $sql)) {
        echo '<script language="javascript">';
        echo 'alert("Guardado exitosamente");';
        echo 'window.location="pacientes.php";';  // Cambia "paciente.php" por la página a la que deseas redirigir
        echo '</script>';
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
    }
}
?>
