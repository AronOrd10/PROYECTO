<?php
include("config.php");

$id = $_GET['id'];
$sql = "UPDATE tb_persona SET estado = 0 WHERE id_persona = $id";

if(mysqli_query($mysqli, $sql)) {
    echo '<script language="javascript">';
    echo 'window.location="medico.php";'; // Cambia "medico.php" por la página a la que deseas redirigir
    echo '</script>';
} else {
    echo "Error al actualizar el estado del médico: " . mysqli_error($mysqli);
}
?>
