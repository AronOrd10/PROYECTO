<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    // Obtener el ID del cliente de la URL
    $id = $_GET['id'];

    // Actualizar el estado del cliente a inactivo (estado = 0)
    $sql ="UPDATE tb_persona SET estado = 0 WHERE id_persona = $id";

    if(mysqli_query($mysqli, $sql)) {
        // Redireccionar a la página de personas después de la actualización
        echo '<script language="javascript">';
        echo 'window.location="personas.php";';
        echo '</script>';
    } else {
        echo "Error al actualizar el estado del cliente: " . mysqli_error($mysqli);
    }
} else {
    echo "No se recibió el ID del cliente";
}
?>
