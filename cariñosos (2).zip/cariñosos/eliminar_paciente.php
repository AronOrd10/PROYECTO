<?php
include("config.php");

// Verificar si se recibió el parámetro 'id' en la URL
if(isset($_GET['id'])) {
    // Obtener el valor del parámetro 'id'
    $id = $_GET['id'];

    // Preparar la consulta SQL para actualizar el estado del paciente
    $sql = "UPDATE tb_persona SET estado = 0 WHERE id_persona = $id";

    // Ejecutar la consulta SQL
    if(mysqli_query($mysqli, $sql)) {
        // Redirigir a la página de personas
        echo '<script language="javascript">';
        echo 'window.location="personas.php";';
        echo '</script>';
    } else {
        // Mostrar un mensaje de error si la consulta falla
        echo "Error al actualizar el estado del paciente: " . mysqli_error($mysqli);
    }
} else {
    // Mostrar un mensaje si no se recibió el parámetro 'id'
    echo "No se recibió el ID del paciente";
}
?>
