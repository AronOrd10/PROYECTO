<?php
include("config.php");

// Verificar si se recibió el parámetro 'id' en la URL
if(isset($_GET['id'])) {
    // Obtener el valor del parámetro 'id'
    $id = $_GET['id'];

    // Preparar la consulta SQL para obtener los datos del horario
    $result = mysqli_query($mysqli, "SELECT * FROM tb_horario WHERE id_horario = $id");

    // Verificar si se encontró el horario
    if(mysqli_num_rows($result) > 0) {
        // Mostrar los datos del horario en un formulario para su actualización
        while ($row = mysqli_fetch_array($result)) {
            ?>
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" type="text/css" href="css/mystyle1.css">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <title>Actualizar Horario</title>
            </head>
            <body>
                <!-- Creamos un menú -->
                <div class="icon-bar">
                    <a href="home.html"><i class="fa fa-home"></i></a>
                    <a href="horarios.php"><i class="fa fa-clock-o"></i></a>
                </div>

                <h2>Actualizar Horario</h2>
                <hr />

                <form action="guardar_horario.php" method="POST">
                    <div class="container">
                        <input type="hidden" name="id" value="<?php echo $row['id_horario']; ?>" required>
                        <label for="hora_entrada"><b>Hora de Entrada</b></label>
                        <input type="time" name="hora_entrada" value="<?php echo $row['hora_entrada']; ?>" required>

                        <label for="hora_salida"><b>Hora de Salida</b></label>
                        <input type="time" name="hora_salida" value="<?php echo $row['hora_salida']; ?>" required>

                        <label for="cantidad_horas"><b>Cantidad de Horas</b></label>
                        <input type="number" name="cantidad_horas" value="<?php echo $row['cantidad_horas']; ?>" required>

                        <label for="id_empleado"><b>ID Empleado</b></label>
                        <input type="text" name="id_empleado" value="<?php echo $row['id_empleado']; ?>" required>

                        <div class="clearfix">
                            <button type="submit" class="signupbtn">Actualizar</button>
                        </div>
                    </div>
                </form>
            </body>
            </html>
            <?php
        }
    } else {
        echo "No se encontraron datos para el horario con ID $id";
    }
} else {
    echo "No se recibió el ID del horario";
}
?>
