<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recopila los datos del formulario
    $debito = $_POST['debito'];
    $credito = $_POST['credito'];
    $efectivo = $_POST['efectivo'];
    $id_factura = $_POST['id_factura'];

    // Realiza la inserción en la base de datos
    $sql = "INSERT INTO tb_forma_pago (debito, credito, efectivo, id_factura) 
            VALUES ('$debito', '$credito', '$efectivo', '$id_factura')";

    if (mysqli_query($mysqli, $sql)) {
        echo '<script language="javascript">';
        
  
echo 'alert("Guardado exitosamente");';
        echo 'window.location="formas_pago.php";';  // Cambia "formas_pago.php" por la página a la que deseas redirigir
        echo '</script>';
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
    }
}

    
