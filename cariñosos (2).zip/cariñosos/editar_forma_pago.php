<?php
include("config.php");

// Verificar si se recibió el parámetro 'id' en la URL
if(isset($_GET['id'])) {
    // Obtener el valor del parámetro 'id'
    $id = $_GET['id'];

    // Preparar la consulta SQL para obtener los datos del cliente
    $result = mysqli_query($mysqli, "SELECT * FROM tb_cliente WHERE id_cliente = $id");

    

 
// Verificar si se encontró el cliente
    if(mysqli_num_rows($result) > 0) {
        
     
// Mostrar los datos del cliente en un formulario para su actualización
        while ($row = mysqli_fetch_array($result)) {
            ?>
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <meta charset=
            <head>
        
"UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" type="text/css" href="css/mystyle1.css">
                <link rel=
         
"stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <title>Actualizar Cliente</title>
            </head>
            <body>
               
                <title>Actualizar forma pago</title>
        
class="icon-bar">
                    <a href="home.html"><i class="fa fa-home"></i></a>
                    <a href="cliente.php"><i class="fa fa-user"></i></a>
                </div>

                <h2>Actualizar Cliente</h2>
                <hr />

                <form action="guardar_cliente.php" method="POST">
                    <div class="container">
                        <input type="hidden" name="id" value="<?php echo $row['id_cliente']; ?>" required>
                        <label for="id_persona"><b>ID Persona:</b></label>
                        <input type="text" name="id_persona" value="<?php echo $row['id_persona']; ?>" required>

                        <label for="codigo_cliente"><b>Código Cliente:</b></label>
                        <input type="text" name="codigo_cliente" value="<?php echo $row['codigo_cliente']; ?>" required>

                        <div class="clearfix">
                            <button type="submit" class="signupbtn">Actualizar</button>
                        </div>
                    </div>
                </form>
            </body>
            </html>
            <?php
        }
    } else {
        
        ec
echo "No se encontraron datos para forma_pago con ID $id";
    }
} else {
    echo "No se recibió el ID de forma_pago";
}
?>