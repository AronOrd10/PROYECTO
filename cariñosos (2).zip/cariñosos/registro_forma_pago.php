<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>Ingresar Datos de Factura</title>
</head>
<body>
    <!-- Creamos un menú -->
    <div class="icon-bar">
        <a href="inicio.php"><i class="fa fa-home"></i></a>
        <a href="persona.php"><i class="fa fa-user"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>Factura</h2>
    <hr>
    <!-- Formulario para ingresar los datos -->
    <form action="guardar_factura.php" method="POST">
        <div class="container">
            <label for="debito"><b>Débito:</b></label>
            <input type="text" name="debito" required>

            <label for="credito"><b>Crédito:</b></label>
            <input type="text" name="credito" required>

            <label for="efectivo"><b>Efectivo:</b></label>
            <input type="text" name="efectivo" required>

            <label for="id_factura"><b>ID Factura:</b></label>
            <input type="text" name="id_factura" required>

            <div class="clearfix">
                <button type="submit" class="signupbtn">Guardar</button>
            </div>
        </div>
    </form>
</body>
</html>
