<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>Ingresar Servicio Adicionales</title>
</head>
<body>
    <!-- Creamos un menú -->
    <div class="icon-bar">
        <a href="inicio.php"><i class="fa fa-home"></i></a>
        <a href="servicio_adicionales.php"><i class="fa fa-calendar"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>Ingresar Servicio Adicionales</h2>
    <hr>
    <!-- Formulario para ingresar los datos del servicio adicional -->
    <form action="guardar_servicio_adicionales.php" method="POST">
        <div class="container">
            <label for="nombre_servivio"><b>Nombre Servicio:</b></label>
            <input type="text" name="nombre_servicio" required>

            <label for="descripcion"><b>Descripcion:</b></label>
            <input type="text" name="descripcion" required>

            <label for="costo"><b>Costo:</b></label>
            <input type="text" name="costo" required>

            <label for="estado"><b>Estado:</b></label>
            <input type="text" name="estado" required>

            <label for="id_cliente"><b>ID Cliente:</b></label>
            <input type="text" name="id_cliente" required>

            <div class="clearfix">
                <button type="submit" class="signupbtn">Guardar</button>
            </div>
        </div>
    </form>
</body>
</html>
