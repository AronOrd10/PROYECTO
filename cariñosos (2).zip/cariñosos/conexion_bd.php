<?php
$conexion mysqli("localhost","root","","bd_cariñosos","");
$conexion->set_charset("uff8");
?>