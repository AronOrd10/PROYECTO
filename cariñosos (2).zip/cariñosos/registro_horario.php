<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>Ingresar Datos de Horario</title>
</head>
<body>
    <!-- Creamos un menú -->
    <div class="icon-bar">
        <a href="inicio.php"><i class="fa fa-home"></i></a>
        <a href="persona.php"><i class="fa fa-user"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>Horario</h2>
    <hr>
    <!-- Creo un formulario para ingresar los datos -->
    <form action="guardar_horario.php" method="POST">
        <div class="container">
            <label for="hora_entrada"><b>Hora de Entrada:</b></label>
            <input type="time" name="hora_entrada" required>

            <label for="hora_salida"><b>Hora de Salida:</b></label>
            <input type="time" name="hora_salida" required>

            <label for="cantidad_horas"><b>Cantidad de Horas:</b></label>
            <input type="number" name="cantidad_horas" required>

            <label for="id_empleado"><b>ID Empleado:</b></label>
            <input type="text" name="id_empleado" required>

            <div class="clearfix">
                <button type="submit" class="signupbtn">Guardar</button>
            </div>
        </div>
    </form>
</body>
</html>
