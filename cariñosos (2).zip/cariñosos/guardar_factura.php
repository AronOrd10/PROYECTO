<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recopila los datos del formulario
    $fecha = $_POST['fecha'];
    $emision = $_POST['emision'];
    $clave = $_POST['clave'];
    $id_cliente = $_POST['id_cliente'];
    $correo = $_POST['correo'];
    $direccion = $_POST['direccion'];

    // Realiza la inserción en la base de datos
    $sql = "INSERT INTO tb_factura (fecha, emision, clave, id_cliente, correo, direccion) 
            VALUES ('$fecha', '$emision', '$clave', '$id_cliente', '$correo', '$direccion')";

    if (mysqli_query($mysqli, $sql)) {
        echo '<script language="javascript">';
        echo 'alert("Guardado exitosamente");';
        echo 'window.location="facturas.php";';  // Cambia "tu_pagina.php" por la página a la que deseas redirigir
        echo '</script>';
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
    }
}
?>
